// app/auth/layout.jsx (Server Component)
import { redirect } from "next/navigation";
import { isAuthenticated } from "@/lib/actions/auth.action";

const AuthLayout = async ({ children }) => {
  const isUserAuthenticated = await isAuthenticated();

  if (isUserAuthenticated) {
    redirect("/"); // redirect authenticated users away from auth pages
  }

  return <div className="auth-layout">{children}</div>;
};

export default AuthLayout;
